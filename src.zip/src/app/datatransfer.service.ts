import { Injectable } from '@angular/core';
import {Subject} from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class DatatransferService {

  constructor() { }

  public obj_Subject = new Subject();

  myfunc(obj){
    this.obj_Subject.next(obj)
  }
}
