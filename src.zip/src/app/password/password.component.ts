import { Component, OnInit } from '@angular/core';
import { CrudService } from '../crud.service';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.css']
})
export class PasswordComponent implements OnInit {
  errMsg:any;
  constructor(private crud:CrudService,private auth:AuthService) { }

  ngOnInit() {
  }
  update_password(x1,x2,x3){
    console.log(x1.value)
    console.log(x2.value)
    console.log(x3.value)

    this.crud.select("users").subscribe(
      (res)=>{
        console.log(res)
        var cnt=0;
        for(let key in res){
          console.log(res[key])
          if(res[key]['password'] == x1.value){
            cnt++;
          }
        }

        if(cnt>0){
          if(x2.value == x3.value){
            var obj = {
              name:this.auth.getUserData("name"),
              email:this.auth.getUserData("email"),
              mobile:this.auth.getUserData("mobile"),
              status:this.auth.getUserData("status"),
              password:x2.value 
            }
            console.log(obj);
            let userid = this.auth.getUserData("id");
            console.log(userid)
            this.crud.update("users",obj,userid).subscribe(
              (res)=>{
                console.log(res)
                this.errMsg = "Password updated"
              }
            )
          }
          else{
            this.errMsg = "Password Mismatch";

          }
        }
        else{
          this.errMsg = "Invalid Current Pass"
        }
      }
    )
  }
}
